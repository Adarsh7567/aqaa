import firebase from "firebase";

//initialize your database
var firebaseConfig = {
  apiKey: "AIzaSyCjNKlkAawzhxQA6KT2jFSBK39YnKXx2EQ",
  authDomain: "kkkkkk-38912.firebaseapp.com",
  databaseURL: "https://kkkkkk-38912-default-rtdb.firebaseio.com",
  projectId: "kkkkkk-38912",
  storageBucket: "kkkkkk-38912.appspot.com",
  messagingSenderId: "16828527277",
  appId: "1:16828527277:web:807c5689848ad808b1cc24"
};
firebase.initializeApp(firebaseConfig);
  export default firebase.database()
 

  